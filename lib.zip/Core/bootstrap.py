
from Core.Core import Core

core = Core.getInstance()
core.init()
