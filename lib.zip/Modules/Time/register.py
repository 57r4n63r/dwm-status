from Modules.Importer import Importer
importer = Importer.getInstance()
importer.register('Modules.Time.Module.Time');
