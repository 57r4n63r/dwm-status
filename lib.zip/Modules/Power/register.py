from Modules.Importer import Importer
importer = Importer.getInstance()
importer.register('Modules.Power.Module.Power');
