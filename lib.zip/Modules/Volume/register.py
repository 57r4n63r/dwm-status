from Modules.Importer import Importer
importer = Importer.getInstance()
importer.register('Modules.Volume.Module.Volume');
