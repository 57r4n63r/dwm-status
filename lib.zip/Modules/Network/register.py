from Modules.Importer import Importer
importer = Importer.getInstance()
importer.register('Modules.Network.Module.Network');
